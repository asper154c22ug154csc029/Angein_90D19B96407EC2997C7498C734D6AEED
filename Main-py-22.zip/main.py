class Player:

  def Play(self):
     print("The player is playing cricket.")
    

class Batsman:
  def Play(self):
    print("The Batsman is batting")


class Bowler:
  def Play(self):
    print("The Bowler is bowling")

Batsman = Batsman()
Bowler = Bowler()


Batsman.Play()
Bowler.Play()